import argparse
import csv
import glob
import io
import json
import os
import shutil
from pathlib import Path

import apache_beam as beam
import pyarrow as pa
from apache_beam import pvalue
from apache_beam.options.pipeline_options import PipelineOptions
from apache_beam.io import ReadFromParquet, ReadFromText, WriteToParquet, WriteToText


CIUDADES_VALIDAS = {"Santiago", "Lima", "Buenos Aires"}

# Esquema de la capa Gold.
GOLD_SCHEMA = pa.schema([
    ("id_transaccion", pa.string()),
    ("ciudad", pa.string()),
    ("monto_usd", pa.float64()),
    ("fecha_transaccion", pa.string()),
])

# Etiquetas para las salidas multiples (Tagged Outputs).
TAG_VALIDOS = "validos"
TAG_RECHAZADOS = "rechazados"


class ValidarContrato(beam.DoFn):
    """Aplica el Data Contract y separa validos vs. rechazados (DLQ)."""

    def process(self, registro):
        monto_texto = registro.get("monto_original")

        # Regla 1: el monto debe ser un numero valido (float/int).
        try:
            monto = float(monto_texto)
        except (TypeError, ValueError):
            yield pvalue.TaggedOutput(TAG_RECHAZADOS, {
                "raw_record": registro,
                "motivo_rechazo": "Monto no corresponde a un formato numerico valido (float/int)",
            })
            return

        # Regla 2: monto > 0  Y  ciudad autorizada en el contrato regional.
        if monto <= 0 or registro.get("ciudad") not in CIUDADES_VALIDAS:
            yield pvalue.TaggedOutput(TAG_RECHAZADOS, {
                "raw_record": registro,
                "motivo_rechazo": "Ciudad no autorizada en contrato regional o monto menor a cero",
            })
            return

        # Registro valido: pasa por la salida principal.
        yield registro


class ConvertirAUSD(beam.DoFn):
    """Cruza el registro valido con el tipo de cambio (Side Input) y arma la fila Gold."""

    def process(self, registro, tasas):
        # 'tasas' es un dict {codigo_moneda: factor_usd} entregado como Side Input.
        factor = tasas[registro["moneda_origen"]]
        monto_usd = float(registro["monto_original"]) * factor
        yield {
            "id_transaccion": registro["id_transaccion"],
            "ciudad": registro["ciudad"],
            "monto_usd": round(monto_usd, 6),
            "fecha_transaccion": registro["fecha_transaccion"],
        }


def parsear_tipo_cambio(linea):
    """Convierte una linea del CSV de tipo de cambio en (codigo_moneda, factor_usd)."""
    codigo, _pais, factor = next(csv.reader(io.StringIO(linea)))
    return (codigo, float(factor))


def deduplicar(clave_valores):
    """Toma el primer registro de cada id_transaccion (deduplicacion)."""
    _id, registros = clave_valores
    return list(registros)[0]


def construir_pipeline(opciones, args):
    from datetime import date
    proc_date = args.proc_date if args.proc_date else date.today().strftime('%Y-%m-%d')
    # Se normalizan los separadores a '/' (Beam usa '/' en su sistema de archivos,
    # incluso en Windows; mezclar '\' rompe el patron glob).
    psa_dir = args.psa_dir.replace("\\", "/").rstrip("/")
    gold_dir = args.gold_dir.replace("\\", "/").rstrip("/")
    errors_dir = args.errors_dir.replace("\\", "/").rstrip("/")
    psa_glob = f"{psa_dir}/proc_date={proc_date}/ventas*.parquet"
    gold_prefijo = f"{gold_dir}/proc_date={proc_date}/ventas_gold"
    dlq_prefijo = f"{errors_dir}/proc_date={proc_date}/dlq_ventas"

    # =========================
    # LIMPIAR SALIDAS
    # =========================

    gold_path = Path(gold_dir) / f"proc_date={proc_date}"
    errors_path = Path(errors_dir) / f"proc_date={proc_date}"

    if gold_path.exists():
        shutil.rmtree(gold_path)

    if errors_path.exists():
        shutil.rmtree(errors_path)

    gold_path.mkdir(parents=True, exist_ok=True)
    errors_path.mkdir(parents=True, exist_ok=True)

    with beam.Pipeline(options=opciones) as p:
        # Side Input: maestro de tipos de cambio como dict distribuido.
        tasas = beam.pvalue.AsDict(
            p
            | "LeerTipoCambio" >> ReadFromText(args.tipo_cambio, skip_header_lines=1)
            | "ParsearTipoCambio" >> beam.Map(parsear_tipo_cambio)
        )

        # --- Rama principal: lectura de PSA y validacion ---
        archivos_psa = [f.replace("\\", "/") for f in glob.glob(psa_glob)]
        if not archivos_psa:
            raise FileNotFoundError(f"No se encontraron archivos PSA en: {psa_glob}")
        lecturas = [
            p | f"LeerPSA_{i}" >> ReadFromParquet(ruta)
            for i, ruta in enumerate(archivos_psa)
        ]
        psa = lecturas | "UnirShardsPSA" >> beam.Flatten()

        # Validacion con salidas etiquetadas (Tagged Outputs).
        resultado = psa | "ValidarContrato" >> beam.ParDo(ValidarContrato()).with_outputs(
            TAG_RECHAZADOS, main=TAG_VALIDOS)

        validos = resultado[TAG_VALIDOS]
        rechazados = resultado[TAG_RECHAZADOS]

        # --- Rama de error: Dead-Letter Queue en JSON Lines ---
        (
            rechazados
            | "SerializarDLQ" >> beam.Map(lambda r: json.dumps(r, ensure_ascii=False))
            | "EscribirDLQ" >> WriteToText(
                file_path_prefix=dlq_prefijo,
                file_name_suffix=".json",
                shard_name_template="",  # nombre fijo -> idempotente al re-ejecutar
            )
        )

        # --- Rama valida: conversion a USD + deduplicacion + capa Gold ---
        (
            validos
            | "ConvertirAUSD" >> beam.ParDo(ConvertirAUSD(), tasas)
            | "ClavearPorId" >> beam.Map(lambda r: (r["id_transaccion"], r))
            | "AgruparPorId" >> beam.GroupByKey()
            | "Deduplicar" >> beam.Map(deduplicar)
            | "EscribirGold_Parquet" >> WriteToParquet(
                file_path_prefix=gold_prefijo,
                schema=GOLD_SCHEMA,
                file_name_suffix=".parquet",
            )
        )


def main(argv=None):
    BASE_DIR = Path(__file__).resolve().parent.parent
    DEFAULT_PSA = str(BASE_DIR / 'data' / 'psa')
    DEFAULT_GOLD = str(BASE_DIR / 'data' / 'gold')
    DEFAULT_ERRORS = str(BASE_DIR / 'data' / 'errors')
    DEFAULT_TC = str(BASE_DIR / 'data' / 'inputs' / 'tipo_cambio.csv')

    parser = argparse.ArgumentParser(description="Job 2 - Transformacion a capa Gold")
    parser.add_argument("--proc_date", required=False,
                        help="Fecha de proceso YYYY-MM-DD (macro {{ ds }} de Airflow)")
    parser.add_argument("--psa_dir", default=DEFAULT_PSA, help="Carpeta de la capa PSA")
    parser.add_argument("--gold_dir", default=DEFAULT_GOLD, help="Carpeta destino Gold")
    parser.add_argument("--errors_dir", default=DEFAULT_ERRORS, help="Carpeta destino DLQ")
    parser.add_argument("--tipo_cambio", default=DEFAULT_TC,
                        help="Ruta del maestro de tipos de cambio")
    args, beam_args = parser.parse_known_args(argv)

    opciones = PipelineOptions(beam_args)
    construir_pipeline(opciones, args)


if __name__ == "__main__":
    main()
